| Subset | Method | n | R (%) | LB attained | Completion |
| --- | --- | --- | --- | --- | --- |
| all | CON | 118 | 85.18 | 90 | 2963.16 |
| all | FSPC | 118 | 99.68 | 116 | 2717.99 |
| all | SLS | 118 | 99.79 | 117 | 2676.15 |
| all | STaR | 118 | 99.34 | 116 | 2672.99 |
| all | FT-SAA | 118 | 99.72 | 116 | 2717.45 |
| certified | CON | 101 | 88.67 | 80 | 2516.62 |
| certified | FSPC | 101 | 99.75 | 100 | 2261.77 |
| certified | SLS | 101 | 99.88 | 101 | 2216.08 |
| certified | STaR | 101 | 99.75 | 100 | 2216.98 |
| certified | FT-SAA | 101 | 99.75 | 100 | 2261.77 |
