| Parameter | Configuration |
| --- | --- |
| Benchmark | Extended Homberger, 1,000 customers per instance. 120 instances from 60 A/B parents. |
| Split and route coverage | 24 development and 96 holdout instances (48 holdout parents). 8,606 routes / 2,891 exposed overall. Holdout: 6,864 / 2,321. |
| Route and energy model | Fixed customers and order, capacity Q = 700, consumption h = 1. Euclidean travel, linear station-specific charging, native units. |
| Station waits | Independent synthetic lognormal waits per visit. 4 reused station attribute tables. Station hours disabled. |
| Search and target | 95% route target. Maximum 64 distinct trials, 131,072 search draws and 5 s cooperative guard. Trials include the original plan. |
| Candidate evaluation | 512 common draws for full stochastic scores, with a 128-draw STaR prefix. Up to 3 nearby eligible stations per considered gap. |
| Validation and inference | 10,000 independent validation draws per plan, paired across methods. One-sided 95% Wilson attainment. 9,999 family-stratified parent bootstrap resamples. |
