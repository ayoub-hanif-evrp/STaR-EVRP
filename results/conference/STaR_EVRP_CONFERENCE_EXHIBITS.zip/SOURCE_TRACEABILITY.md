# Source traceability

Publication snapshot under `data/inputs/`. Archive `star-research-archive-v1` / `1ad987a328679263e5d8ba40330ffe1a11409db1`. Frozen executable `c657aa69d55178c85b4759475933b36d1bcc2181`.

Active exhibits read only the snapshot. Historical Phase 3/5/6 paths are archival references.

## Snapshot files

- `ablation_summary.csv` — `2dbf781005fa61730c69ba9017dabd481b9e7691e55f627b105df820ba76f6f8`
- `all120_descriptive.json` — `580b9de9b85af7b06b3981eced90f45b6f0c2f4ee6ecec4267f0a4d68d6c11e4`
- `archival_disclosure.json` — `128ea6ec303188456fec95dacb5c757402cf83534fa795d6cf4a546137d6ea08`
- `config.json` — `3d209b28fde6d7e189c30664a37834a10fd1df8bd4f2b00a300568ed0be43f95`
- `display_anchors.json` — `20132bfb09890f70e0dca3bddcafcbcb4f3f92948cc9771c6ab5f89474b70f44`
- `fig01_charging_events.csv` — `512a30a7da00822a3811a6fc2ee54117f63479c60967a87eea306d649aef6796`
- `fig01_metrics.csv` — `1fb51e9b0482119fd24de929609edee3b91b0370785dcc567c42c48e1ea4abfa`
- `fig01_nodes.csv` — `ae4b8db2b8cb26b8e9af1ccb36d2f21dba1434e26916ece2caee0231b516138e`
- `fig01_physical_summary.csv` — `592bb807e4c8ba8ce0391d36edf1df2842d49bb30e3ac22844768378e244ac12`
- `fig01_route.json` — `81de09923cb89c824539ecab1a6a2ca8a7644b5cef83c7ca55e9e4da230d83b4`
- `fig01_stops.csv` — `00012a0227ec218713037e0e6b0881e639c449b7317e07c27b241c54389437ab`
- `holdout_route_metrics.csv` — `dd1b8fb1d90e5dc3e8b8ea80dd2c7777b518314d43c3314bb24eadb56e723712`
- `method_summary.csv` — `990822f624821ce4f709134ec4fe37967f3fde145668f893e106dc49303f9a90`
- `paired_effects_holdout.csv` — `abdb51bcb8b6a019d986e869ae3913ea970464391d1187071a3a3160acebaff3`
- `paired_routes_CON.csv` — `a7e5d6cd7904f57cf24c170e276beb373c848fadc79b15f86f7d1f4237b38a44`
- `paired_routes_MWR.csv` — `2ff93fb6477611c7d6cd1f207719b450d4d573d5feb0f3a98ff9faa45c58fc0d`
- `paired_routes_QBR.csv` — `51cc5c15cb5a61fa3cb662dd4233fd3ae34fc1f0a39370d5009add118b6def9e`
- `snapshot_manifest.json` — `6d53c0c4ccfa5b231aa7392808c57d5e5f247536b3fef421f96cd17ffd3745b6`
- `visit_bin_effects.csv` — `d78309b2f1e024a3e63af45d6880e88f6a5add9fd0aab0b3cc29a0c91fffa534`
- `visit_bin_routes.csv` — `baf1c8c7e68f0e87de20341354087a999077bd2244d1ad0b2c07072e0964c883`

## Companion archive locations (at pinned tag)

- `star-research-archive-v1:results/phase5/data/paired_effects.csv`
- `star-research-archive-v1:results/phase6/data/mechanism_strata.csv`
- `star-research-archive-v1:results/phase3/`

See `docs/ARCHIVE_AND_REPRODUCTION.md` for worktree recovery commands.
