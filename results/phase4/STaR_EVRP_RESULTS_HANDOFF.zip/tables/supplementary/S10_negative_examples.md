| Parent | V | Route | Observed mode | R (%) | LB (%) | Cust. | Depot | Both |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| R2_10_2 | A | 1 | customer_only | 31.53 | 30.77 | 6847 | 0 | 0 |
| C2_10_4 | A | 30 | joint | 85.39 | 84.80 | 1421 | 1461 | 1421 |
| R2_10_9 | A | 5 | point_only | 95.29 | 94.93 | 471 | 0 | 0 |
