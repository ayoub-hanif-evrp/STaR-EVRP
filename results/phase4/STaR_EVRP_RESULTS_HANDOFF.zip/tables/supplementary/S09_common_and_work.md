| Control | Metric | n | Difference [95% CI] |
| --- | --- | --- | --- |
| B4 | Completion on common attainers | 2158 | -35.56 [-37.45, -33.70] |
| B4 | Route-relative completion (%) | 2321 | -1.67 [-1.76, -1.59] |
| B4 | Distinct plans | 2321 | +42.49 [+41.53, +43.47] |
| B4 | Process CPU ms | 2321 | +21.59 [+20.40, +22.83] |
| B3 | Completion on common attainers | 2182 | -1.59 [-3.08, -0.11] |
| B3 | Route-relative completion (%) | 2321 | -0.03 [-0.10, +0.03] |
| B3 | Distinct plans | 2321 | +0.32 [+0.23, +0.42] |
| B3 | Process CPU ms | 2321 | +2.08 [+1.50, +2.67] |
