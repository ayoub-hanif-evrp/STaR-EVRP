| Control | Endpoint (unit) | Pairs | Difference [95% CI] | Class |
| --- | --- | --- | --- | --- |
| B4 | R (pp) | 2321 | +1.24 [+0.86, +1.65] | Primary |
| B4 | LB attainment (pp) | 2321 | +2.15 [+1.49, +2.90] | Exploratory |
| B4 | Completion (native) | 2321 | -33.15 [-34.86, -31.48] | Exploratory |
| B4 | Search draws | 2321 | +8767 [+8461, +9074] | Exploratory |
| B4 | Wall (ms) | 2321 | +21.32 [+20.18, +22.52] | Exploratory |
| B3 | R (pp) | 2321 | +0.32 [+0.13, +0.49] | Exploratory |
| B3 | LB attainment (pp) | 2321 | +0.78 [+0.27, +1.36] | Exploratory |
| B3 | Completion (native) | 2321 | -1.60 [-3.05, -0.14] | Exploratory |
| B3 | Search draws | 2321 | -6887 [-7217, -6584] | Exploratory |
| B3 | Wall (ms) | 2321 | +2.18 [+1.63, +2.73] | Exploratory |
| STaR_no_partial | R (pp) | 2321 | +3.12 [+2.22, +3.97] | Exploratory |
| STaR_no_partial | LB attainment (pp) | 2321 | +4.95 [+3.59, +6.34] | Exploratory |
| STaR_no_partial | Completion (native) | 2321 | -94.70 [-99.32, -89.90] | Exploratory |
