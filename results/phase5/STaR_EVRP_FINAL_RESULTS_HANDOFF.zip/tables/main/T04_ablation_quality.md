| Cohort | Method | R (%) | LB / n | LB (%) | Completion |
| --- | --- | --- | --- | --- | --- |
| 96 holdout | STaR | 97.31 | 2211/2321 | 95.26 | 3135.83 |
| 96 holdout | STaR-NPC | 94.19 | 2096/2321 | 90.31 | 3230.53 |
| 96 holdout | STaR-NSP | 97.01 | 2197/2321 | 94.66 | 3137.47 |
| 96 holdout | STaR-NAS | 97.31 | 2207/2321 | 95.09 | 3135.74 |
| 96 holdout | STaR-NPP | 97.31 | 2211/2321 | 95.26 | 3135.83 |
| 24 development | STaR | 96.01 | 531/570 | 93.16 | 3303.05 |
| 24 development | STaR-NPC | 91.99 | 497/570 | 87.19 | 3383.82 |
| 24 development | STaR-NSP | 96.15 | 534/570 | 93.68 | 3305.32 |
| 24 development | STaR-NAS | 96.01 | 531/570 | 93.16 | 3303.05 |
| 24 development | STaR-NPP | 96.01 | 531/570 | 93.16 | 3303.05 |
| All 120 (descriptive) | STaR | 97.06 | 2742/2891 | 94.85 | 3168.80 |
| All 120 (descriptive) | STaR-NPC | 93.76 | 2593/2891 | 89.69 | 3260.75 |
| All 120 (descriptive) | STaR-NSP | 96.84 | 2731/2891 | 94.47 | 3170.56 |
| All 120 (descriptive) | STaR-NAS | 97.05 | 2738/2891 | 94.71 | 3168.73 |
| All 120 (descriptive) | STaR-NPP | 97.06 | 2742/2891 | 94.85 | 3168.80 |
