| Holdout c64 evidence | Pairs | Parents | Estimate or comparison | Status |
| --- | --- | --- | --- | --- |
| STaR – FSPC reliability (pp) | 2321 | 48 | +1.24 [+0.86, +1.65] | Confirmatory |
| Parent-equal reliability (pp) | 2321 | 48 | 1.12 [0.79, 1.47] | Sensitivity |
| STaR – SLS reliability (pp) | 2321 | 48 | +0.32 [+0.13, +0.49] | Exploratory |
| STaR vs SLS search draws | 2321 | 48 | 13024 / 19911 (34.59% fewer) | Descriptive |
| STaR vs SLS wall ms | 2321 | 48 | 29.69 / 27.51 | Descriptive |
| STaR vs FSPC actual trials | 2321 | 48 | 62.67 / 20.18 | Descriptive |
