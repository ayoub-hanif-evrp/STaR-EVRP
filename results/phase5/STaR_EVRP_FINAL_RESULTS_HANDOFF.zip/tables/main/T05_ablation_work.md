| Partition | Method | Trials | Draws | Screen rej. | Prefix rej. | Wall ms | CPU ms |
| --- | --- | --- | --- | --- | --- | --- | --- |
| holdout | STaR | 62.67 | 13024 | 3.12 | 15.37 | 29.69 | 30.15 |
| holdout | STaR-NPC | 57.29 | 8400 | 2.80 | 12.96 | 27.41 | 27.61 |
| development | STaR-NAS | 62.75 | 13823 | 0.00 | 16.53 | 23.29 | 23.30 |
| development | STaR-NPP | 62.75 | 18515 | 3.24 | 0.00 | 21.85 | 22.20 |
| development | STaR-NSP | 62.45 | 13768 | 3.96 | 11.00 | 24.40 | 24.81 |
| holdout | STaR-NAS | 62.67 | 13569 | 0.00 | 18.10 | 23.54 | 23.78 |
| holdout | STaR-NPP | 62.67 | 18927 | 3.12 | 0.00 | 22.13 | 22.56 |
| holdout | STaR-NSP | 62.35 | 13080 | 3.94 | 12.56 | 23.89 | 24.35 |
| development | STaR | 62.75 | 13275 | 3.24 | 13.65 | 20.54 | 20.39 |
| development | STaR-NPC | 57.35 | 8489 | 2.85 | 11.01 | 19.54 | 20.15 |
