| Cohort | Control | Metric | n | STaR diff. [95% CI] |
| --- | --- | --- | --- | --- |
| Holdout | SLS | Plan trials | 2321 | +0.32 [+0.23, +0.42] |
| Holdout | SLS | Wall ms | 2321 | +2.18 [+1.63, +2.73] |
| Holdout | SLS | CPU ms | 2321 | +2.08 [+1.50, +2.67] |
| Holdout | SLS | Completion, joint LB | 2182 | -1.59 [-3.08, -0.11] |
| Holdout | FSPC | Plan trials | 2321 | +42.49 [+41.53, +43.47] |
| Holdout | FSPC | Wall ms | 2321 | +21.32 [+20.18, +22.52] |
| Holdout | FSPC | CPU ms | 2321 | +21.59 [+20.40, +22.83] |
| Holdout | FSPC | Completion, joint LB | 2158 | -35.56 [-37.45, -33.70] |
| Holdout | STaR-NAS | Plan trials | 2321 | +0.00 [+0.00, +0.00] |
| Holdout | STaR-NAS | Completion, joint LB | 2207 | +0.09 [+0.00, +0.27] |
| Holdout | STaR-NPP | Plan trials | 2321 | +0.00 [+0.00, +0.00] |
| Holdout | STaR-NPP | Completion, joint LB | 2211 | +0.00 [+0.00, +0.00] |
| Holdout | STaR-NSP | Plan trials | 2321 | +0.32 [+0.23, +0.42] |
| Holdout | STaR-NSP | Completion, joint LB | 2186 | -1.61 [-3.10, -0.12] |
| Holdout | STaR-NPC | Plan trials | 2321 | +5.38 [+5.05, +5.71] |
| Holdout | STaR-NPC | Wall ms | 2321 | +2.28 [+1.65, +2.87] |
| Holdout | STaR-NPC | CPU ms | 2321 | +2.54 [+1.84, +3.20] |
| Holdout | STaR-NPC | Completion, joint LB | 2040 | -94.95 [-100.16, -89.46] |
| Dev. | SLS | Plan trials | 570 | +0.30 [+0.09, +0.51] |
| Dev. | SLS | Wall ms | 570 | +1.29 [+1.08, +1.49] |
| Dev. | SLS | CPU ms | 570 | +1.07 [+0.53, +1.59] |
| Dev. | SLS | Completion, joint LB | 526 | -2.45 [-4.92, -0.08] |
| Dev. | FSPC | Plan trials | 570 | +40.86 [+40.12, +41.58] |
| Dev. | FSPC | Wall ms | 570 | +14.06 [+13.12, +15.02] |
| Dev. | FSPC | CPU ms | 570 | +13.82 [+12.95, +14.70] |
| Dev. | FSPC | Completion, joint LB | 517 | -37.01 [-40.64, -33.31] |
| Dev. | STaR-NAS | Plan trials | 570 | +0.00 [+0.00, +0.00] |
| Dev. | STaR-NAS | Wall ms | 570 | -2.75 [-3.58, -1.95] |
| Dev. | STaR-NAS | CPU ms | 570 | -2.91 [-3.96, -1.87] |
| Dev. | STaR-NAS | Completion, joint LB | 531 | +0.00 [+0.00, +0.00] |
| Dev. | STaR-NPP | Plan trials | 570 | +0.00 [+0.00, +0.00] |
| Dev. | STaR-NPP | Wall ms | 570 | -1.31 [-1.94, -0.71] |
| Dev. | STaR-NPP | CPU ms | 570 | -1.81 [-2.48, -1.14] |
| Dev. | STaR-NPP | Completion, joint LB | 531 | +0.00 [+0.00, +0.00] |
| Dev. | STaR-NSP | Plan trials | 570 | +0.30 [+0.09, +0.51] |
| Dev. | STaR-NSP | Wall ms | 570 | -3.86 [-4.97, -2.84] |
| Dev. | STaR-NSP | CPU ms | 570 | -4.41 [-5.83, -3.09] |
| Dev. | STaR-NSP | Completion, joint LB | 527 | -2.52 [-5.01, -0.10] |
| Dev. | STaR-NPC | Plan trials | 570 | +5.40 [+4.91, +5.90] |
| Dev. | STaR-NPC | Wall ms | 570 | +1.00 [+0.36, +1.63] |
| Dev. | STaR-NPC | CPU ms | 570 | +0.25 [-0.72, +1.15] |
| Dev. | STaR-NPC | Completion, joint LB | 482 | -81.33 [-101.74, -61.90] |
| All 120 | SLS | Plan trials | 2891 | +0.32 [+0.23, +0.41] |
| All 120 | SLS | Completion, joint LB | 2708 | -1.76 [-3.06, -0.47] |
| All 120 | FSPC | Plan trials | 2891 | +42.17 [+41.38, +42.96] |
| All 120 | FSPC | Completion, joint LB | 2675 | -35.84 [-37.55, -34.17] |
| All 120 | STaR-NAS | Plan trials | 2891 | +0.00 [+0.00, +0.00] |
| All 120 | STaR-NAS | Completion, joint LB | 2738 | +0.07 [+0.00, +0.22] |
| All 120 | STaR-NPP | Plan trials | 2891 | +0.00 [+0.00, +0.00] |
| All 120 | STaR-NPP | Completion, joint LB | 2742 | +0.00 [+0.00, +0.00] |
| All 120 | STaR-NSP | Plan trials | 2891 | +0.32 [+0.23, +0.41] |
| All 120 | STaR-NSP | Completion, joint LB | 2713 | -1.78 [-3.09, -0.50] |
| All 120 | STaR-NPC | Plan trials | 2891 | +5.38 [+5.10, +5.67] |
| All 120 | STaR-NPC | Completion, joint LB | 2522 | -92.35 [-98.00, -86.67] |
