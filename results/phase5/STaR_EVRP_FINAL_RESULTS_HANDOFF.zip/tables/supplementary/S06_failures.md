| Cohort | Family | V | n | LB | Point only | Customer | Depot | Joint |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 96 holdout | C1 | A | 67 | 67 | 0 | 0 | 0 | 0 |
| 96 holdout | C1 | B | 19 | 19 | 0 | 0 | 0 | 0 |
| 96 holdout | C2 | A | 188 | 187 | 0 | 0 | 0 | 1 |
| 96 holdout | C2 | B | 142 | 142 | 0 | 0 | 0 | 0 |
| 96 holdout | R1 | A | 328 | 328 | 0 | 0 | 0 | 0 |
| 96 holdout | R1 | B | 368 | 368 | 0 | 0 | 0 | 0 |
| 96 holdout | R2 | A | 237 | 189 | 2 | 45 | 0 | 1 |
| 96 holdout | R2 | B | 191 | 173 | 0 | 18 | 0 | 0 |
| 96 holdout | RC1 | A | 216 | 216 | 0 | 0 | 0 | 0 |
| 96 holdout | RC1 | B | 163 | 163 | 0 | 0 | 0 | 0 |
| 96 holdout | RC2 | A | 226 | 204 | 1 | 21 | 0 | 0 |
| 96 holdout | RC2 | B | 176 | 155 | 1 | 20 | 0 | 0 |
| All 120 (descriptive) | C1 | A | 70 | 70 | 0 | 0 | 0 | 0 |
| All 120 (descriptive) | C1 | B | 23 | 23 | 0 | 0 | 0 | 0 |
| All 120 (descriptive) | C2 | A | 215 | 214 | 0 | 0 | 0 | 1 |
| All 120 (descriptive) | C2 | B | 171 | 171 | 0 | 0 | 0 | 0 |
| All 120 (descriptive) | R1 | A | 417 | 417 | 0 | 0 | 0 | 0 |
| All 120 (descriptive) | R1 | B | 470 | 470 | 0 | 0 | 0 | 0 |
| All 120 (descriptive) | R2 | A | 303 | 231 | 2 | 69 | 0 | 1 |
| All 120 (descriptive) | R2 | B | 239 | 214 | 0 | 25 | 0 | 0 |
| All 120 (descriptive) | RC1 | A | 265 | 265 | 0 | 0 | 0 | 0 |
| All 120 (descriptive) | RC1 | B | 215 | 215 | 0 | 0 | 0 | 0 |
| All 120 (descriptive) | RC2 | A | 282 | 255 | 1 | 26 | 0 | 0 |
| All 120 (descriptive) | RC2 | B | 221 | 197 | 1 | 23 | 0 | 0 |
